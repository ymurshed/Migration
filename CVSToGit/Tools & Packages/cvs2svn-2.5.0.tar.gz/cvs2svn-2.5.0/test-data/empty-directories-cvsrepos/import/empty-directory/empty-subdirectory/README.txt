This directory should be created when its parent directory is created,
namely when d.txt is added.
