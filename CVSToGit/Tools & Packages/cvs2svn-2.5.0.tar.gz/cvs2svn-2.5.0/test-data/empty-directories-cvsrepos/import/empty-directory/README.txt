This empty directory should be created when d.txt is created.
