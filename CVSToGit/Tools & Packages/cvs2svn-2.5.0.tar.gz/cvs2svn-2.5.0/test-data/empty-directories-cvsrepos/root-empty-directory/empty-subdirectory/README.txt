This directory should be created when its parent is created.
